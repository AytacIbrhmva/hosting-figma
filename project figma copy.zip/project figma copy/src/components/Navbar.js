import React from 'react';
import '../styles/Navbar.css';
import { Link } from 'react-router-dom';

export default function Navbar() {
  return (
    <nav className='w-full h-[120px] bg-darkBlue px-20 flex items-center  justify-between' >

        {/* logo */}
        <a href='' className='text-white font-bold text-xl '>Host Beta</a>
        {/* menu */}
        <div className="menu">
            <ul className='flex items-center gap-10'>
                <li>
                    <Link to='/' className="py-2.5 font-medium text-sm text-white hover:text-lightBlue transition duration-300 ">Home</Link>
                </li>
                <li>
                    <Link to='/' className="py-2.5 font-medium text-sm text-white hover:text-lightBlue transition duration-300 ">About</Link>
                </li>
                <li>
                    <Link to='/services' className="py-2.5 font-medium text-sm text-white hover:text-lightBlue transition duration-300 ">Services</Link>
                </li>
                <li>
                    <Link to='/pricing' className="py-2.5 font-medium text-sm text-white hover:text-lightBlue transition duration-300 ">Pricing</Link>
                </li>
                <li>
                    <Link to='/testimonials' className="py-2.5 font-medium text-sm text-white hover:text-lightBlue transition duration-300 ">Testimonials</Link>
                </li>
            </ul>
        
        </div> 
        {/* cta */}
        <div className='w-[180px] h-[70px] border-2 border-white flex items-center justify-center text-xl font-semibold text-white items-center hover:bg-white hover:text-darkBlue cursor-pointer transition duration-300'> 
            Contact Us
        </div>
      
    </nav>
  )
}

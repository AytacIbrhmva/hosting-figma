import React from 'react'

export default function () {
  return (
    <div className='px-20 h-[100vh] flex items-center justify-center'>

        {/* left side */}
        <div>
            <div className='w-[346px] h-[611px] bg-contain bg-no-repeat bg-studentAbout'>

            </div>
        </div>

        {/* right side */}
        <div>

        </div>

    </div>
  )
}
